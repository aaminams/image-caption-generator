const API_ENDPOINT = 'https://api.anthropic.com/v1/messages';
const claude_API_KEY = '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';



document.getElementById('uploadImgInput').addEventListener('change', function(event) {
    document.querySelector('#generatedCaption').innerText = "You will see your caption here.";
    const file = event.target.files[0];
    if (file) {
        const reader = new FileReader();
        reader.onload = function(e) {
            const img = document.getElementById('uploadedImage');
            img.src = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});


document.getElementById('uploadImgBtn').addEventListener('click', function() {
    document.getElementById('uploadImgInput').click();
});



document.getElementById('generateCaption').addEventListener('click', async function() {
    setLoading(true);
    const img = document.getElementById('uploadedImage');
    const parts = img.src.split(',');

    const imageData = parts.slice(1).join('');
    
    const [metadata] = parts[0].split(';');
    const [scheme, imageType] = metadata.split(':');

    const bodyPrompt = {
        "model": "claude-3-opus-20240229",
        "max_tokens": 1024,
        "messages": [
            {"role": "user", "content": [
      {
        "type": "image",
        "source": {
          "type": "base64",
          "media_type": imageType,
          "data": imageData,
        }
      },
      {"type": "text", "text": "Can you generate a social media caption for this image? **Please only response with social media caption**"}
    ]}
        ]
    }
    
    const req = await fetch(API_ENDPOINT, {
            method: 'POST',
            headers: {
                "Content-Type": "application/json",
                "x-api-key" : claude_API_KEY,
                "anthropic-version": "2023-06-01"
            },
            body: JSON.stringify(bodyPrompt),
    })

    const resFromAi = await req.json();
    if(resFromAi.error){
        alert(resFromAi.error.message);
        setLoading(false);
        return;
    }

    console.log(resFromAi);
    document.querySelector('#generatedCaption').innerText = resFromAi.content[0].text;
    setLoading(false);
    
});




function setLoading(state){
    if(state === true){
            document.querySelector('.spinner').style.display = 'block';
            document.querySelector('#generateCaption span').innerText = "Generating Caption"
            document.querySelector('#generateCaption').ariaDisabled = true;
    }else{
        document.querySelector('.spinner').style.display = 'none';
        document.querySelector('#generateCaption span').innerText = "Generate Caption"
        document.querySelector('#generateCaption').ariaDisabled = false;

    }
}

document.querySelector('.generatedCaptionDisplay').addEventListener('click', async () => {
    const generatedCaption = document.getElementById('generatedCaption').innerText;

    try {
        await navigator.clipboard.writeText(generatedCaption);
        alert('Text copied to clipboard');
    } catch (err) {
        console.error('Unable to copy text to clipboard:', err);

    }
});




